<?php

$data = array("Hello this is the diagnosis for this patient");

echo json_encode($data);